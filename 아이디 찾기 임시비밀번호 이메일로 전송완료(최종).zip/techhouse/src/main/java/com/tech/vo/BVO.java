package com.tech.vo;

public interface BVO {
}
